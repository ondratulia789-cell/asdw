/* All screen components for Asi Moc redesign. Mobile 390px wide. */

/* ---------- Icons (compact inline SVG; stroke 1.6) ---------- */
const I = {
  Menu: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>),
  Sparkle: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M12 3l1.8 4.6L18 9l-4.2 1.4L12 15l-1.8-4.6L6 9l4.2-1.4L12 3z"/><path d="M19 16l.8 1.8 1.8.8-1.8.8L19 21l-.8-1.6-1.8-.8 1.8-.8L19 16z"/></svg>),
  Upload: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M20 16v4H4v-4"/></svg>),
  Shield: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-3z"/></svg>),
  Lock: (p) => (<svg viewBox="0 0 24 24" width={p.s||14} height={p.s||14} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>),
  Bolt: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z"/></svg>),
  Smile: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="10" x2="9.01" y2="10"/><line x1="15" y1="10" x2="15.01" y2="10"/></svg>),
  Play: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5v-7z" fill="currentColor"/></svg>),
  Clock: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>),
  Calendar: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>),
  Trophy: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M7 4h10v4a5 5 0 0 1-10 0V4z"/><path d="M5 5H3a3 3 0 0 0 3 3M19 5h2a3 3 0 0 1-3 3M9 14h6M10 18h4M8 22h8"/></svg>),
  Flame: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M12 3s4 4 4 8a4 4 0 1 1-8 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3 0-5 0-7z"/></svg>),
  Crown: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M3 7l4 4 5-6 5 6 4-4-2 12H5L3 7z"/></svg>),
  Check: (p) => (<svg viewBox="0 0 24 24" width={p.s||14} height={p.s||14} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 5 5 9-11"/></svg>),
  Eye: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>),
  Arrow: (p) => (<svg viewBox="0 0 24 24" width={p.s||18} height={p.s||18} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>),
  FileJson: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5z"/><path d="M14 3v5h5"/><path d="M9 14h.01M9 17h6"/></svg>),
  Download: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 4v12"/><path d="m7 11 5 5 5-5"/><path d="M4 20h16"/></svg>),
  Money: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="3"/></svg>),
  Moon: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/></svg>),
  Brain: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-1 5 3 3 0 0 0 1 5v1a3 3 0 0 0 6 0V4a2 2 0 0 0-3 0z"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 1 5 3 3 0 0 1-1 5v1a3 3 0 0 1-6 0V4a2 2 0 0 1 3 0z"/></svg>),
  Globe: (p) => (<svg viewBox="0 0 24 24" width={p.s||20} height={p.s||20} fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>),
  Share: (p) => (<svg viewBox="0 0 24 24" width={p.s||16} height={p.s||16} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="m8 10.5 8-3.5M8 13.5l8 3.5"/></svg>),
};

/* ---------- Shared bits ---------- */
const TopBar = ({ ticker }) => (
  <div className="topbar">
    <div className="logo">
      <span className="logo-mark"><span/><span/><span/><span/></span>
      <span className="logo-name">Asi Moc</span>
    </div>
    {ticker !== false && (
      <div className="ticker">
        <I.Sparkle s={13}/> <span>aneta_*** právě zjistila svoje stats</span>
      </div>
    )}
    <button className="menu-btn"><I.Menu/></button>
  </div>
);

const Eyebrow = ({ children }) => <span className="eyebrow">{children}</span>;

/* ============================================================
   01 — Landing
============================================================ */
function LandingScreen() {
  return (
    <div className="scr scroll-host" style={{height: '100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar/>
        <section className="hero">
          <h1>
            Kolik času jsi <span className="pink-text">reálně</span><br/>
            strávil na <span className="cyan-text">TikToku</span>?
          </h1>
          <p className="sub">Nahraj svoje TikTok data a zjisti reálné statistiky.</p>

          <div style={{marginTop: 26}}>
            <button className="btn-neon"><I.Upload/> Nahraj svá data</button>
          </div>
          <div style={{display:'flex', justifyContent:'center', marginTop: 16}}>
            <span className="chip"><I.Lock s={11}/> Bezpečně. Soukromě. Jen tvoje data.</span>
          </div>
        </section>

        {/* Phone preview */}
        <div className="phone-wrap">
          <div className="phone">
            <div className="phone-screen">
              <div className="pcard-head">
                <I.Sparkle s={14}/>
                <span className="ttl">Tvoje realita</span>
              </div>
              <div className="pcard">
                <div className="lbl">Zhlédnutých videí</div>
                <div className="big">247 391</div>
                <svg viewBox="0 0 200 40" style={{width:'100%', height:38, marginTop:6}}>
                  <defs>
                    <linearGradient id="ln1" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#19D4F5"/><stop offset="100%" stopColor="#FF3D88"/>
                    </linearGradient>
                  </defs>
                  <path d="M0 30 Q 25 18, 50 22 T 100 14 T 150 18 T 200 8" stroke="url(#ln1)" strokeWidth="2.2" fill="none"/>
                </svg>
              </div>
              <div className="mini-grid">
                <div className="mini">
                  <div className="head"><I.Clock s={12}/><span className="l">Celkový čas</span></div>
                  <div className="v cyan-text">1 384h</div>
                </div>
                <div className="mini">
                  <div className="head"><I.Calendar s={12}/><span className="l">Průměrně denně</span></div>
                  <div className="v pink-text">3h 24m</div>
                </div>
                <div className="mini">
                  <div className="head"><I.Bolt s={12}/><span className="l">Nejdelší session</span></div>
                  <div className="v purple-text">6h 12m</div>
                </div>
                <div className="mini">
                  <div className="head"><I.Eye s={12}/><span className="l">Počet session</span></div>
                  <div className="v" style={{color:'#fff'}}>1 463</div>
                </div>
              </div>
              <div style={{textAlign:'center', marginTop: 14, color:'var(--fg-3)', fontSize: 11}}>
                <I.Lock s={10}/> <span style={{verticalAlign:'middle', marginLeft:4}}>A mnohem víc...</span>
              </div>
            </div>
          </div>
        </div>

        {/* Features (Funk-ce) */}
        <div style={{marginTop: 50}}>
          <h2 className="section-h"><span style={{color:'#fff'}}>Funk</span><span className="grad-text">ce</span></h2>
          <div style={{height: 16}}/>
          <div className="features">
            <div className="feature">
              <div className="ic-wrap" style={{color:'var(--cyan-2)'}}><I.Shield/></div>
              <div className="t">100% soukromí</div>
              <div className="d">Tvoje data nikde neukládáme.</div>
            </div>
            <div className="feature pink">
              <div className="ic-wrap" style={{color:'var(--pink-2)'}}><I.Bolt/></div>
              <div className="t">Okamžité výsledky</div>
              <div className="d">Získej kompletní přehled během pár sekund.</div>
            </div>
            <div className="feature">
              <div className="ic-wrap" style={{color:'var(--cyan-2)'}}><I.Smile/></div>
              <div className="t">Otevři oči</div>
              <div className="d">Čísla, která tě možná překvapí.</div>
            </div>
          </div>
        </div>

        {/* Discovery — Co všechno zjistíš */}
        <div style={{marginTop: 40}}>
          <h2 className="section-h">Co všechno <span className="grad-text">zjistíš</span></h2>
          <div style={{height: 16}}/>
          <div style={{display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap: 8}}>
            {[
              {ic: <I.Play s={20}/>, l:'Počet zhlédnutých videí', c:'var(--cyan-2)'},
              {ic: <I.Clock s={20}/>, l:'Celkový čas na TikToku', c:'var(--cyan-2)'},
              {ic: <I.Calendar s={20}/>, l:'Průměrný čas denně', c:'var(--pink-2)'},
              {ic: <I.Bolt s={20}/>, l:'Nejdelší session', c:'var(--purple)'},
              {ic: <I.Trophy s={20}/>, l:'Srovnání s ostatními uživateli', c:'var(--cyan-2)'},
            ].map((d, i) => (
              <div key={i} className="disc" style={{minHeight: 110, padding:'12px 6px'}}>
                <span style={{color: d.c}}>{d.ic}</span>
                <div className="lab" style={{fontSize:10.5, lineHeight:1.3}}>{d.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div style={{marginTop: 36}} className="cta-block">
          <h3>Jsi připraven zjistit svou <span className="pink-text">realitu</span>?</h3>
          <button className="btn-neon"><I.Upload s={16}/> Chci vidět svá čísla</button>
          <div className="note">Zabere to 2 minuty</div>
        </div>

        {/* Social proof */}
        <div style={{marginTop: 28, textAlign:'center'}}>
          <div className="stars">★★★★★</div>
          <div style={{fontSize:12.5, color:'var(--fg-3)', marginTop:6}}>
            Připojilo se už <span className="grad-text" style={{fontWeight:700}}>50 000+</span> lidí
          </div>
        </div>

        {/* Demo entry */}
        <button className="btn-ghost" style={{marginTop: 22}}>
          <I.Eye/> Podívej se, jak to vypadá <span style={{marginLeft:'auto'}}><I.Arrow s={14}/></span>
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   02 — Upload focused
============================================================ */
function UploadFocusScreen() {
  return (
    <div className="scr" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar/>
        <Eyebrow>Krok 1 — Nahraj data</Eyebrow>
        <h2 className="section-h" style={{marginTop: 10}}>Pošli <span className="grad-text">TikTok export</span></h2>
        <p className="section-sub">Soubor .json, .zip nebo .txt z Nastavení → Stáhnout data.</p>

        <div className="upload-card" style={{marginTop: 20}}>
          <div className="uc-ic" style={{color:'#fff'}}><I.Upload s={22}/></div>
          <div className="uc-t">Přetáhni sem soubor</div>
          <div className="uc-d">nebo klikni a vyber ze zařízení</div>
          <div style={{marginTop: 16}}>
            <button className="btn-neon"><I.FileJson s={16}/> Vybrat soubor</button>
          </div>
          <div className="uc-d" style={{marginTop: 12}}>Max 100 MB • .zip / .json / .txt</div>
        </div>

        <div style={{display:'flex', justifyContent:'center', marginTop:14}}>
          <span className="chip"><I.Shield s={12}/> Soubor zpracujeme v prohlížeči, na server nic neposíláme.</span>
        </div>

        <div className="div-line"/>
        <Eyebrow>Jak na to</Eyebrow>
        <div style={{display:'grid', gap:10, marginTop:14}}>
          <div className="step">
            <span className="n">1</span><span style={{flex:1}} className="lab">Otevři TikTok → Nastavení → Účet</span>
            <span className="ic"><I.Arrow s={14}/></span>
          </div>
          <div className="step">
            <span className="n">2</span><span style={{flex:1}} className="lab">Stáhnout data → Vše → JSON</span>
            <span className="ic"><I.Download/></span>
          </div>
          <div className="step">
            <span className="n">3</span><span style={{flex:1}} className="lab">Nahraj soubor sem — výsledek za 5 s</span>
            <span className="ic"><I.Sparkle/></span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   03 — Locked free preview
============================================================ */
function LockedScreen() {
  return (
    <div className="scr scroll-host" style={{height: '100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>
        <div style={{display:'flex', justifyContent:'center'}}>
          <span className="tier-badge std"><I.Check s={11}/> Data nahrána</span>
        </div>

        <div style={{textAlign:'center', marginTop: 22}}>
          <Eyebrow>Tvůj náhled zdarma</Eyebrow>
          <div className="big-hero-num" style={{marginTop: 10}}>83 048</div>
          <div style={{fontSize: 13, color:'var(--fg-3)', letterSpacing:'0.15em', textTransform:'uppercase', marginTop:6}}>minut na TikToku</div>
          <div style={{fontSize: 13.5, color: 'var(--fg-2)', marginTop: 14}}>
            ...a <span style={{fontFamily:'Space Grotesk', fontWeight:700}}>247 391</span> videí.
          </div>
        </div>

        <div className="div-line"/>

        <Eyebrow>Co odemkneš</Eyebrow>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginTop: 14}}>
          <div className="locked-card">
            <I.Clock s={14}/>
            <div className="v" style={{marginTop:6}}>184 min</div>
            <div style={{fontSize:10, color:'var(--fg-3)', marginTop:4}}>denní průměr</div>
          </div>
          <div className="locked-card">
            <span className="lock-pill"><I.Lock s={9}/> PRO</span>
            <I.Flame s={14}/>
            <div className="v blur" style={{marginTop:6}}>••••</div>
            <div style={{fontSize:10, color:'var(--fg-3)', marginTop:4}}>rekordní den</div>
          </div>
          <div className="locked-card">
            <span className="lock-pill"><I.Lock s={9}/> PRO</span>
            <I.Moon s={14}/>
            <div className="v blur" style={{marginTop:6}}>••••</div>
            <div style={{fontSize:10, color:'var(--fg-3)', marginTop:4}}>noční sova</div>
          </div>
        </div>

        <div style={{marginTop: 20, display:'flex', justifyContent:'center'}}>
          <span className="chip" style={{color:'var(--fg-2)'}}>
            ⏳ Speciální sleva vyprší za <b style={{marginLeft:4, color:'#fff', fontFamily:'Space Grotesk'}}>04:42</b>
          </span>
        </div>

        <div className="div-line"/>

        {/* Pricing inline */}
        <div style={{textAlign:'center'}}>
          <span className="label-eyebrow">Ceník</span>
          <h2 className="section-h" style={{marginTop:12}}>Vyber si svou <span className="grad-text">úroveň pravdy</span></h2>
          <p className="section-sub">Jednorázová platba. Žádné předplatné. Doživotní přístup.</p>
        </div>

        <div style={{display:'grid', gap:14, marginTop: 22}}>
          {/* Free */}
          <div className="price-card">
            <div className="tier">Náhled <span className="label-eyebrow" style={{fontSize:9, padding:'2px 6px'}}>Hook</span></div>
            <div className="blurb">Jen ochutnávka. Uvidíš pár čísel.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">0</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Celkový čas + počet videí</li>
              <li><I.Check/> Ostatní statistiky rozmazané</li>
            </ul>
            <div style={{textAlign:'center', color:'var(--fg-3)', fontSize:11, padding:'8px 0'}}>Aktuálně vidíš tuto úroveň</div>
          </div>

          {/* Standard featured */}
          <div className="price-card featured">
            <span className="badge"><I.Sparkle s={10}/> Nejoblíbenější</span>
            <div className="tier">Standard</div>
            <div className="blurb">Plný dashboard se všemi čísly.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">79</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Vše z Náhledu</li>
              <li><I.Check/> Rekordy, denní průměr, sessions</li>
              <li><I.Check/> Posledních 30 dní</li>
              <li><I.Check/> Standardní sdílecí karta</li>
            </ul>
            <button className="btn-neon"><I.Lock s={14}/> Odemknout Standard</button>
          </div>

          {/* Premium */}
          <div className="price-card">
            <div className="tier"><I.Crown s={14}/> Premium</div>
            <div className="blurb">Plný dashboard + extrémní metriky + 9:16 share.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">149</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Vše ze Standard</li>
              <li><I.Check/> Kolik peněz jsi protočil/a</li>
              <li><I.Check/> Noční sova score</li>
              <li><I.Check/> Maratony, knihy, Země kolem</li>
              <li><I.Check/> Dopamine rating</li>
              <li><I.Check/> Premium 9:16 karta na Stories</li>
            </ul>
            <button className="btn-ghost" style={{padding:'12px 18px'}}><I.Lock s={14}/> Odemknout Premium</button>
          </div>
        </div>

        <div style={{textAlign:'center', fontSize:11, color:'var(--fg-3)', marginTop:14}}>
          Bezpečná platba přes Stripe. Funguje karta i Apple/Google Pay.
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   04 — Standard unlocked
============================================================ */
function StandardScreen() {
  return (
    <div className="scr scroll-host" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>
        <div style={{display:'flex', justifyContent:'center'}}>
          <span className="tier-badge std">Standard aktivní</span>
        </div>

        <div style={{textAlign:'center', marginTop: 18}}>
          <Eyebrow>1. led 2024 – 31. pro 2024</Eyebrow>
          <div className="big-hero-num" style={{marginTop: 12}}>83 048</div>
          <div style={{fontSize: 13, color:'var(--fg-3)', letterSpacing:'0.15em', textTransform:'uppercase', marginTop:6}}>minut na TikToku</div>
          <div style={{display:'flex', justifyContent:'center', marginTop: 18}}>
            <div className="seg">
              <button>Minuty</button><button className="on">Hodiny</button><button>Dny</button>
            </div>
          </div>
        </div>

        {/* Secondary stats */}
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginTop: 22}}>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Play s={16} style={{color:'var(--pink-2)'}}/>
            <div className="v pink-text" style={{fontSize:18, marginTop:6}}>247 391</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Videí</div>
          </div>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Flame s={16} style={{color:'var(--purple)'}}/>
            <div className="v purple-text" style={{fontSize:18, marginTop:6}}>372 min</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Nejdelší session</div>
          </div>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Calendar s={16} style={{color:'var(--cyan-2)'}}/>
            <div className="v cyan-text" style={{fontSize:18, marginTop:6}}>227 min</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Denně průměr</div>
          </div>
        </div>

        <div className="div-line"/>

        <Eyebrow>Rekordy</Eyebrow>
        <div style={{display:'grid', gap:10, marginTop:14}}>
          <div className="record">
            <div className="r-ic" style={{color:'var(--purple)'}}><I.Trophy/></div>
            <div style={{flex:1}}>
              <div className="r-lab">Rekordní den</div>
              <div className="r-val">14. úno • 532 min</div>
            </div>
          </div>
          <div className="record">
            <div className="r-ic" style={{color:'var(--cyan-2)'}}><I.Calendar/></div>
            <div style={{flex:1}}>
              <div className="r-lab">Rekordní týden</div>
              <div className="r-val">3 142 minut</div>
            </div>
          </div>
        </div>

        <div className="div-line"/>

        {/* Last 30 days */}
        <div className="chart-card">
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div>
              <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.18em', fontWeight:600}}>Posledních 30 dní</div>
              <div style={{display:'flex', gap: 18, marginTop: 10}}>
                <div>
                  <div style={{fontFamily:'Space Grotesk', fontWeight:700, fontSize:22}} className="cyan-text">6 824</div>
                  <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:2}}>minut</div>
                </div>
                <div>
                  <div style={{fontFamily:'Space Grotesk', fontWeight:700, fontSize:22}} className="pink-text">19 240</div>
                  <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:2}}>videí</div>
                </div>
              </div>
            </div>
            <div style={{width: 70, height: 40, position:'relative'}}>
              <svg viewBox="0 0 100 40" style={{width:'100%', height:'100%'}}>
                <defs>
                  <linearGradient id="ln-st" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#19D4F5"/><stop offset="100%" stopColor="#FF3D88"/></linearGradient>
                </defs>
                <path d="M0 30 L 15 22 L 30 26 L 45 14 L 60 18 L 75 8 L 100 12" fill="none" stroke="url(#ln-st)" strokeWidth="2.2"/>
              </svg>
            </div>
          </div>
          <div className="bars">
            {Array.from({length: 30}).map((_, i) => {
              const heights = [50,30,42,60,38,28,70,46,52,80,68,40,55,72,48,58,82,64,38,46,70,90,58,42,60,76,84,50,68,72];
              return <div key={i} style={{height: heights[i] + '%'}}/>;
            })}
          </div>
        </div>

        <div className="div-line"/>

        {/* Share card */}
        <Eyebrow>Sdílej svá čísla</Eyebrow>
        <div style={{display:'flex', justifyContent:'center', marginTop: 18}}>
          <div className="share-card">
            <div>
              <Eyebrow>tvoje 2024 na TikToku</Eyebrow>
            </div>
            <div>
              <div className="sc-num grad-text">1 384h</div>
              <div className="sc-lab" style={{marginTop:6}}>na TikToku</div>
            </div>
            <div className="sc-foot">asimoc.cz</div>
          </div>
        </div>
        <button className="btn-neon" style={{marginTop: 18}}><I.Share s={16}/> Stáhnout sdílecí kartu</button>

        <button className="reset">← Nahrát jiná data</button>
      </div>
    </div>
  );
}

/* ============================================================
   05 — Premium unlocked
============================================================ */
function PremiumScreen() {
  return (
    <div className="scr scroll-host" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>
        <div style={{display:'flex', justifyContent:'center'}}>
          <span className="tier-badge prem"><I.Crown s={11}/> Premium aktivní</span>
        </div>

        <div style={{textAlign:'center', marginTop: 18}}>
          <Eyebrow>1. led 2024 – 31. pro 2024</Eyebrow>
          <div className="big-hero-num" style={{marginTop: 12}}>1 384</div>
          <div style={{fontSize: 13, color:'var(--fg-3)', letterSpacing:'0.15em', textTransform:'uppercase', marginTop:6}}>hodin na TikToku</div>
          <div style={{display:'flex', justifyContent:'center', marginTop: 18}}>
            <div className="seg">
              <button>Minuty</button><button className="on">Hodiny</button><button>Dny</button>
            </div>
          </div>
        </div>

        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginTop: 22}}>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Play s={16} style={{color:'var(--pink-2)'}}/>
            <div className="v pink-text" style={{fontSize:18, marginTop:6}}>247 391</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Videí</div>
          </div>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Flame s={16} style={{color:'var(--purple)'}}/>
            <div className="v purple-text" style={{fontSize:18, marginTop:6}}>372 min</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Nejdelší session</div>
          </div>
          <div className="mini" style={{textAlign:'center', padding:'14px 10px'}}>
            <I.Calendar s={16} style={{color:'var(--cyan-2)'}}/>
            <div className="v cyan-text" style={{fontSize:18, marginTop:6}}>227 min</div>
            <div style={{fontSize:10, color:'var(--fg-3)', textTransform:'uppercase', letterSpacing:'.1em', marginTop:4}}>Denně průměr</div>
          </div>
        </div>

        <div className="div-line"/>

        <Eyebrow>Extrémní metriky</Eyebrow>
        <div style={{display:'grid', gap:10, marginTop:14}}>
          <div className="extreme-metric">
            <div className="em-ic" style={{color:'var(--purple)'}}><I.Money/></div>
            <div style={{flex:1}}>
              <div className="em-lab">Kolik jsi protočil/a v reklamách</div>
              <div className="em-val grad-text">≈ 18 420 Kč</div>
            </div>
          </div>
          <div className="extreme-metric cyan">
            <div className="em-ic" style={{color:'var(--cyan-2)'}}><I.Moon/></div>
            <div style={{flex:1}}>
              <div className="em-lab">Noční sova score</div>
              <div className="em-val cyan-text">8.4 / 10</div>
            </div>
          </div>
          <div className="extreme-metric pink">
            <div className="em-ic" style={{color:'var(--pink-2)'}}><I.Globe/></div>
            <div style={{flex:1}}>
              <div className="em-lab">Země kolem dokola</div>
              <div className="em-val pink-text">2,7×</div>
            </div>
          </div>
          <div className="extreme-metric">
            <div className="em-ic" style={{color:'var(--purple)'}}><I.Brain/></div>
            <div style={{flex:1}}>
              <div className="em-lab">Dopamine rating</div>
              <div className="em-val purple-text">Extreme</div>
            </div>
          </div>
        </div>

        <div className="div-line"/>

        {/* Premium story card */}
        <Eyebrow>Premium story card</Eyebrow>
        <div className="story-card" style={{marginTop:14}}>
          <Eyebrow>Tvůj rok na TikToku</Eyebrow>
          <div style={{textAlign:'center', padding: '18px 0'}}>
            <div style={{fontFamily:'Space Grotesk', fontWeight:800, fontSize: 60, letterSpacing:'-0.03em'}} className="grad-text">1 384h</div>
            <div style={{fontSize:11.5, color:'var(--fg-3)', letterSpacing:'.18em', textTransform:'uppercase', marginTop:6}}>= 57 dní non-stop</div>
          </div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 8, marginTop:6}}>
            <div style={{padding:'10px 12px', borderRadius: 14, background:'rgba(0,0,0,0.3)', border:'1px solid rgba(255,255,255,0.08)'}}>
              <div style={{fontSize:9.5, color:'var(--fg-3)', letterSpacing:'.14em', textTransform:'uppercase'}}>Maratony</div>
              <div style={{fontFamily:'Space Grotesk', fontWeight:700, fontSize:16}} className="pink-text">42</div>
            </div>
            <div style={{padding:'10px 12px', borderRadius: 14, background:'rgba(0,0,0,0.3)', border:'1px solid rgba(255,255,255,0.08)'}}>
              <div style={{fontSize:9.5, color:'var(--fg-3)', letterSpacing:'.14em', textTransform:'uppercase'}}>Knih nepřečteno</div>
              <div style={{fontFamily:'Space Grotesk', fontWeight:700, fontSize:16}} className="cyan-text">128</div>
            </div>
          </div>
        </div>

        <button className="btn-neon" style={{marginTop: 18}}><I.Share s={16}/> Stáhnout 9:16 Story</button>
        <button className="reset">← Nahrát jiná data</button>
      </div>
    </div>
  );
}

/* ============================================================
   06 — Pricing
============================================================ */
function PricingScreen() {
  return (
    <div className="scr scroll-host" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>
        <div style={{textAlign:'center'}}>
          <span className="label-eyebrow">Ceník</span>
          <h2 className="section-h" style={{marginTop:12, fontSize: 26}}>Vyber si svou <span className="grad-text">úroveň pravdy</span></h2>
          <p className="section-sub">Jednorázová platba. Žádné předplatné. Doživotní přístup k tvým datům.</p>
        </div>

        <div style={{display:'grid', gap:14, marginTop: 22}}>
          <div className="price-card">
            <div className="tier">Náhled <span className="label-eyebrow" style={{fontSize:9, padding:'2px 6px'}}>Hook</span></div>
            <div className="blurb">Jen ochutnávka. Uvidíš pár čísel.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">0</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Celkový čas + počet videí</li>
              <li><I.Check/> Ostatní statistiky rozmazané</li>
            </ul>
            <div style={{textAlign:'center', color:'var(--fg-3)', fontSize:11, padding:'8px 0'}}>Aktuálně vidíš tuto úroveň</div>
          </div>

          <div className="price-card featured">
            <span className="badge"><I.Sparkle s={10}/> Nejoblíbenější</span>
            <div className="tier">Standard</div>
            <div className="blurb">Plný dashboard se všemi čísly.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">79</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Vše z Náhledu</li>
              <li><I.Check/> Rekordy, denní průměr, sessions</li>
              <li><I.Check/> Posledních 30 dní</li>
              <li><I.Check/> Standardní sdílecí karta</li>
            </ul>
            <button className="btn-neon"><I.Lock s={14}/> Odemknout Standard</button>
          </div>

          <div className="price-card">
            <div className="tier"><I.Crown s={14}/> Premium</div>
            <div className="blurb">Plný dashboard + extrémní metriky + 9:16 share.</div>
            <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:8}}>
              <div className="price">149</div><span style={{color:'var(--fg-3)', fontSize:12}}>Kč</span>
            </div>
            <ul>
              <li><I.Check/> Vše ze Standard</li>
              <li><I.Check/> Kolik peněz jsi protočil/a</li>
              <li><I.Check/> Noční sova score</li>
              <li><I.Check/> Maratony, knihy, Země kolem</li>
              <li><I.Check/> Dopamine rating</li>
              <li><I.Check/> Premium 9:16 karta na Stories</li>
            </ul>
            <button className="btn-ghost" style={{padding:'12px 18px'}}><I.Lock s={14}/> Odemknout Premium</button>
          </div>
        </div>

        <div style={{textAlign:'center', fontSize:11, color:'var(--fg-3)', marginTop:14}}>
          Bezpečná platba přes Stripe. Funguje karta i Apple/Google Pay.
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   07 — Demo
============================================================ */
function DemoScreen() {
  return (
    <div className="scr scroll-host" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>

        <div className="demo-banner">
          <I.Eye s={16}/>
          <div style={{flex:1, lineHeight:1.35}}>
            <div style={{color:'#fff', fontFamily:'Space Grotesk'}}>Toto je demo náhled</div>
            <div style={{color:'var(--fg-3)', fontSize:11, fontWeight:500, marginTop:2}}>Ukázková data — ne tvoje.</div>
          </div>
          <span style={{fontSize:11, color:'var(--fg-2)'}}>← zpět</span>
        </div>

        <div style={{textAlign:'center', marginTop: 20}}>
          <Eyebrow>aneta_*** — demo profil</Eyebrow>
          <div className="big-hero-num" style={{marginTop: 12}}>1 384</div>
          <div style={{fontSize: 13, color:'var(--fg-3)', letterSpacing:'0.15em', textTransform:'uppercase', marginTop:6}}>hodin na TikToku</div>
        </div>

        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginTop: 22}}>
          <div className="mini" style={{padding:'14px 12px'}}>
            <div className="head"><I.Calendar s={12}/><span className="l">Průměrně denně</span></div>
            <div className="v pink-text">3h 24m</div>
          </div>
          <div className="mini" style={{padding:'14px 12px'}}>
            <div className="head"><I.Bolt s={12}/><span className="l">Nejdelší session</span></div>
            <div className="v purple-text">6h 12m</div>
          </div>
          <div className="mini" style={{padding:'14px 12px'}}>
            <div className="head"><I.Play s={12}/><span className="l">Videí</span></div>
            <div className="v cyan-text">247 391</div>
          </div>
          <div className="mini" style={{padding:'14px 12px'}}>
            <div className="head"><I.Eye s={12}/><span className="l">Sessions</span></div>
            <div className="v" style={{color:'#fff'}}>1 463</div>
          </div>
        </div>

        <div className="div-line"/>

        <div className="chart-card">
          <Eyebrow>Aktivita za rok</Eyebrow>
          <div className="bars" style={{height: 100, marginTop: 16}}>
            {[40,60,30,70,50,80,55,90,65,75,45,82,68,90,72,58,84,76,50,68,72,88,62,50,70,80,90,66,72,84,58,72,90,76].map((h,i)=>(
              <div key={i} style={{height: h+'%'}}/>
            ))}
          </div>
        </div>

        <div className="div-line"/>

        <Eyebrow>Co bys měl/a ty?</Eyebrow>
        <div className="cta-block" style={{marginTop: 14}}>
          <h3>Chceš vidět <span className="grad-text">svoje čísla</span>?</h3>
          <button className="btn-neon"><I.Upload s={16}/> Nahraj svá data</button>
          <div className="note">2 minuty • soukromé • zdarma náhled</div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   08 — Instructions
============================================================ */
function InstructionsScreen() {
  return (
    <div className="scr scroll-host" style={{height:'100%'}}>
      <div className="scr-bg"/>
      <div className="scr-inner">
        <TopBar ticker={false}/>

        <div style={{textAlign:'center'}}>
          <Eyebrow>Návod</Eyebrow>
          <h2 className="section-h" style={{marginTop: 10, fontSize: 26}}>Jak stáhnout <span className="grad-text">TikTok data</span></h2>
          <p className="section-sub">Krok za krokem. Trvá to ~2 minuty + čekání na export.</p>
        </div>

        <div style={{display:'grid', gap: 10, marginTop: 22}}>
          {[
            {n:'1', t:'Otevři TikTok → Profil → ☰ Menu'},
            {n:'2', t:'Nastavení a soukromí → Účet'},
            {n:'3', t:'Stáhnout data → vyber JSON formát'},
            {n:'4', t:'Klikni na „Vyžádat data"'},
            {n:'5', t:'Počkej, až přijde e‑mail (1–24 h)'},
            {n:'6', t:'Stáhni .zip a nahraj sem na Asi Moc'},
          ].map((s) => (
            <div key={s.n} className="step">
              <span className="n">{s.n}</span>
              <span className="lab" style={{flex:1}}>{s.t}</span>
            </div>
          ))}
        </div>

        <div className="div-line"/>

        <div className="cta-block">
          <h3>Tvoje data <span className="grad-text">jsou bezpečná</span></h3>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 10, marginTop: 10}}>
            <div className="feature">
              <div className="ic-wrap" style={{color:'var(--cyan-2)'}}><I.Shield/></div>
              <div className="t">V prohlížeči</div>
              <div className="d">Nahráváš jen lokálně.</div>
            </div>
            <div className="feature pink">
              <div className="ic-wrap" style={{color:'var(--pink-2)'}}><I.Lock s={18}/></div>
              <div className="t">Šifrované</div>
              <div className="d">Žádný server nic neukládá.</div>
            </div>
            <div className="feature">
              <div className="ic-wrap" style={{color:'var(--cyan-2)'}}><I.Bolt/></div>
              <div className="t">5 sekund</div>
              <div className="d">Výpočet je instant.</div>
            </div>
          </div>
          <button className="btn-neon" style={{marginTop: 18}}><I.Upload s={16}/> Mám soubor — nahrát</button>
        </div>
      </div>
    </div>
  );
}

/* Export to window for design canvas access */
Object.assign(window, {
  LandingScreen, UploadFocusScreen, LockedScreen,
  StandardScreen, PremiumScreen, PricingScreen,
  DemoScreen, InstructionsScreen,
});
